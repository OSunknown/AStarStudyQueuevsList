﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Node : IComparable<Node> {

	public bool walkable;
	public Vector3 worldPosition;
	public int gridX;
	public int gridY;

	public int gCost;
	public int hCost;
	public Node parent;

    public int typeNum = 0;

	public Node(bool _walkable, Vector3 _worldPos, int _gridX, int _gridY)
	{
		this.walkable = _walkable;
		this.worldPosition = _worldPos;
		gridX = _gridX;
		gridY = _gridY;
	}

	public int fCost
	{
		get
		{
            if ((gCost + hCost) == 0)
            {
                return int.MaxValue;
            }
			return gCost + hCost;
		}
	}

    public void SetCost(int GC, int HC, Node node)
    {
        if (GC + HC < fCost)
        {
            gCost = GC;
            hCost = HC;
            parent = node;
        }
    }

    public void ChangeClose()
    {
        typeNum = 2;
    }

    public int CompareTo(Node other)
    {
        if(fCost == other.fCost)
        {
            if(hCost == other.hCost)
            {
                return gCost < other.gCost ? 1 : -1;
            }
            return hCost < other.hCost ? -1 : 1;
        }
        return fCost- other.fCost;
    }
}
