﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Diagnostics;

public class Pathfinding : MonoBehaviour {

	public Transform seeker, target;
	Grid grid;
    public bool isList;
	void Start () 
	{
		grid = GetComponent<Grid> ();
    }

	void Update()
	{
        if(Input.GetMouseButtonDown(0))
        {
            grid.Reset();
            FindPath(seeker.position, target.position);
        }
    }

	void FindPath(Vector3 startPos, Vector3 targetPos)
	{
        Stopwatch sw = new Stopwatch();
        sw.Start();

		Node startNode = grid.NodeFromWorldPosition(startPos);
		Node targetNode = grid.NodeFromWorldPosition(targetPos);
        Node NextSelet = null;
        Node temp = null;
        if (isList)
        {
            startNode.gCost = 0;
            startNode.hCost = GetDistance(startNode, targetNode);
            List<Node> OpenSet = new List<Node>();
            OpenSet.Add(startNode);
            for(int i = 0; ; i++)
            {
                int min = int.MaxValue;
                
                Node currentNode = OpenSet[0];
                List<Node> neighbors = grid.GetNeighbours(currentNode);
                foreach (Node n in neighbors)
                {
                    if (!n.walkable)
                        continue;

                    if (n == targetNode)
                    {
                        n.parent = currentNode;
                        RetracePath(startNode, targetNode);
                        sw.Stop();
                        UnityEngine.Debug.Log("Search Complete :" + sw.ElapsedMilliseconds + "ms");
                        return;
                    }
                    if(n.typeNum == 0)
                    {
                        n.typeNum = 1;
                        n.SetCost(currentNode.gCost + GetDistance(n, currentNode), GetDistance(n, targetNode), currentNode);
                        OpenSet.Add(n);
                    }else if(n.typeNum == 1)
                    {
                        n.SetCost(currentNode.gCost + GetDistance(n, currentNode), GetDistance(n, targetNode), currentNode);
                    }
                }
                currentNode.ChangeClose();
                OpenSet.Remove(currentNode);                

                foreach (Node n in OpenSet)
                {
                    if (min > n.fCost)
                    {
                        min = n.fCost;
                        NextSelet = n;
                    }
                    else if (min == n.fCost)
                    {
                        if (NextSelet.hCost > n.hCost)
                        {
                            NextSelet = n;
                        }
                        else if (NextSelet.hCost == n.hCost)
                        {
                            if (NextSelet.gCost < n.gCost)
                            {
                                NextSelet = n;
                            }
                        }
                    }
                }

                int Match = OpenSet.IndexOf(NextSelet);
                temp = OpenSet[0];
                OpenSet[0] = NextSelet;
                OpenSet[Match] = temp;
            }
        }
        else
        {
            //List<Node> openSet = new List<Node> ();
            PriorityQueue<Node> openSet = new PriorityQueue<Node>();

            HashSet<Node> closedSet = new HashSet<Node>();
            openSet.Enqueue(startNode);
            startNode.gCost = 0;
            startNode.hCost = GetDistance(startNode, targetNode);

            while (openSet.Count() > 0)
            {
                // OpenSet에서 가장 낮은 fCost를 가지는 노드를 가져온다. 
                // 만일 fCost가 동일할 경우 gCost가 적은 쪽을 택함. 

                Node currentNode = openSet.Dequeue();


                // 만일 현재 노드가 최종 노드면 탐색을 종료한다.
                if (currentNode == targetNode)
                {
                    RetracePath(startNode, targetNode);

                    sw.Stop();
                    UnityEngine.Debug.Log("Search Complete :" + sw.ElapsedMilliseconds + "ms");
                    return;
                }

                // 해당 노드를 OpenSet에서 빼내고 ClosedSet에 추가한다.
                //openSet.Remove(currentNode);
                closedSet.Add(currentNode);
                currentNode.ChangeClose();
                // 해당 노드에 인접한 이웃 노드를 구한다.  
                List<Node> neighbors = grid.GetNeighbours(currentNode);
                foreach (Node n in neighbors)
                {
                    // 이웃 노드가 ClosedSet에 있거나 걸어다니지 못하는 곳이면 제외한다.
                    if (closedSet.Contains(n) || !n.walkable)
                    {
                        continue;
                    }
                    n.typeNum = 1;
                    // 이웃 노드의 fCost를 모두 계산한다.
                    int gCost = GetDistance(n, currentNode);
                    int hCost = GetDistance(n, targetNode);
                    int fCost = gCost + hCost;

                    // 이웃 노드가 OpenSet에 있는지 검사한다.  
                    if (openSet.Contains(n))
                    {
                        // 있으면 fCost를 비교하고 신규 노드의 fCost 값이 더 적으면 값을 재조정. ( gCost와 부모 변경 )
                        // 이 때도 fCost가 같은 경우 gCost가 적은 쪽을 택함.
                        if (fCost < n.fCost || (fCost == n.gCost && hCost < n.gCost))
                        {
                            n.gCost = gCost;
                            n.parent = currentNode;
                            openSet.Rearrange();
                        }
                    }
                    else
                    {
                        // 없으면 gCost와 hCost를 할당하고 CurrentNode를 부모 노드로 등록한 후 OpenSet에 추가한다.
                        n.gCost = gCost;
                        n.hCost = hCost;
                        n.parent = currentNode;
                        openSet.Enqueue(n);
                    }
                }
            }
        }
    }

    void opensetCheck(PriorityQueue<Node> openSet)
    {
        List<Node> sorting = openSet.returnlist();
        string s = sorting.Count + " ";
        for (int i = 0; i < sorting.Count; i++)
        {
            
            s += sorting[i].fCost + " ";
            
            if (i == 0 || i == 2 || i ==6 || i == 14 || i == 30  || i == 62)
            {
                s += "/";
            }
        }
      //  UnityEngine.Debug.Log(s);
    }

	void RetracePath(Node startNode, Node endNode)
	{
		List<Node> path = new List<Node> ();
		Node currentNode = endNode;

		while (currentNode != startNode) {
			path.Add (currentNode);
			currentNode = currentNode.parent;
		}

		path.Reverse ();
		grid.path = path;
	}

	int GetDistance(Node nodeA, Node nodeB)
	{
		int dstX = Mathf.Abs(nodeA.gridX - nodeB.gridX);
		int dstY = Mathf.Abs(nodeA.gridY - nodeB.gridY);

		if(dstX > dstY)
		{
			return 14*dstY + 10*(dstX - dstY);
		}

        if (dstX == dstY)
        {
            return 14 * dstY;
        }
        
        return 14*dstX + 10*(dstY - dstX);
	}
}
