﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System;

public class Employee : IComparable<Employee>
{
	public string lastName;
	public double priority; // Smaller values are higher priority

	public Employee(string lastName, double priority)
	{
		this.lastName = lastName;
		this.priority = priority;
	}

	public override string ToString()
	{
		return "(" + lastName + ", " + priority.ToString("F1") + ")";
	}

	public int CompareTo(Employee other)
	{
		if (this.priority  < other.priority) return -1;
		else if (this.priority  > other.priority) return 1;
		else return 0;
	}
}

public class PriorityQueue<T> where T : IComparable<T>
{
	private List <T> data;

	public PriorityQueue()
	{
		this.data = new List <T>();
	}

    public bool Contains(T item)
    {
        return data.Contains(item);
    }

    public void Rearrange()
    {
        int li = data.Count - 1;
        int pi = 0;

        while (true)
        {
            int ci = pi * 2 + 1; //자식노드 왼쪽 위치

            if (ci > li) break;

            int rc = ci + 1; //자식노드 오른쪽 위치

            //왼쪽 자식과 오른쪽 자식 비교.
            //오른쪽자식이 왼쪽자식보다 우선순위 낮음?
            //오른족 자식 위치가 끝위치보다 낮거나 같음
            if (rc <= li && data[rc].CompareTo(data[ci]) < 0)
                ci = rc;

            //우선순위가 부모와 자식이 같거나 부모가 더 작다면 멈춰
            if (data[pi].CompareTo(data[ci]) <= 0) break;

            //스왑
            T tmp = data[pi];
            data[pi] = data[ci];
            data[ci] = tmp;

            //위치
            pi = ci;
        }
    }

	public void Enqueue(T item)
	{
		data.Add(item);
		int ci = data.Count - 1;
		while (ci  > 0)
		{
			int pi = (ci - 1) / 2;
			if (data[ci].CompareTo(data[pi])  >= 0)
            {
                break;
            }
			T tmp = data[ci];
            data[ci] = data[pi];
            data[pi] = tmp;
			ci = pi;
		}
    }

	public T Dequeue()
	{
		// Assumes pq isn't empty
		int li = data.Count - 1;
		T frontItem = data[0];
		data[0] = data[li];
		data.RemoveAt(li);

		--li;
		int pi = 0;
		while (true)
		{
			int ci = pi * 2 + 1; //자식노드 왼쪽 위치

			if (ci  > li) break;

			int rc = ci + 1; //자식노드 오른쪽 위치

            //왼쪽 자식과 오른쪽 자식 비교.
            //오른쪽자식이 왼쪽자식보다 우선순위 낮음?
            //오른족 자식 위치가 끝위치보다 낮거나 같음
            
			if (rc  <= li && data[rc].CompareTo(data[ci])  < 0) 
				ci = rc;

            //우선순위가 부모와 자식이 같거나 부모가 더 작다면 멈춰
			if (data[pi].CompareTo(data[ci])  <= 0) break;

            //스왑
			T tmp = data[pi];
            data[pi] = data[ci];
            data[ci] = tmp;

            //위치
			pi = ci;
		}
		return frontItem;
	}

    public List<T> returnlist()
    {
        return data;
    }

	public int Count()
	{
		return data.Count;
	}

	public T Peek()
	{
		T frontItem = data[0];
		return frontItem;
	}

	public override string ToString()
	{
		string s = "";
		for (int i = 0; i  < data.Count; ++i)
			s += data[i].ToString() + " ";
		s += "count = " + data.Count;
		return s;
	}

	public bool IsConsistent()
	{
		if (data.Count == 0) return true;
		int li = data.Count - 1; // last index
		for (int pi = 0; pi  < data.Count; ++pi) // each parent index
		{
			int lci = 2 * pi + 1; // left child index
			int rci = 2 * pi + 2; // right child index
			if (lci  <= li && data[pi].CompareTo(data[lci])  > 0) return false;
			if (rci  <= li && data[pi].CompareTo(data[rci])  > 0) return false;
		}
		return true; // Passed all checks
	}
		
}

public class PriorityQueueTest : MonoBehaviour {

	// Use this for initialization
	void Start () 
	{
		Debug.Log("Begin Priority Queue demo");
		Debug.Log("Creating priority queue of Employee items");
		PriorityQueue <Employee > pq = new PriorityQueue <Employee >();

		// Demo code here 
		Employee e1 = new Employee("Aiden", 1.0);
		Employee e2 = new Employee("Baker", 2.0);

		Debug.Log("Adding " + e1.ToString() + " to priority queue");
		pq.Enqueue(e1);
		Debug.Log("Adding " + e2.ToString() + " to priority queue");
		pq.Enqueue(e2);

		if (pq.Count () > 0) {
			Employee e = pq.Peek ();
			Debug.Log("The front employee is " + e.ToString ());
		}


		TestPriorityQueue (10000);
		Debug.Log("End Priority Queue demo");
	}

	void TestPriorityQueue(int numOperations)
	{
		System.Random rand = new System.Random(0);
		PriorityQueue <Employee > pq = 
			new PriorityQueue <Employee >();
		for (int op = 0; op  < numOperations; ++op)
		{
			int opType = rand.Next(0, 2);

			if (opType == 0) // enqueue
			{
				string lastName = op + "man";
				double priority = 
					(100.0 - 1.0) * rand.NextDouble() + 1.0;
				pq.Enqueue(new Employee(lastName, priority));
				if (pq.IsConsistent() == false)
				{
					Debug.Log("Test fails after enqueue operation # " + op);
				}
			}
			else // Dequeue
			{
				if (pq.Count()  > 0)
				{
					Employee e = pq.Dequeue();
					if (pq.IsConsistent() == false)
					{
						Debug.Log("Test fails after dequeue operation # " + op);
					}
				}
			}
		} // for
		Debug.Log("\nAll tests passed");
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
